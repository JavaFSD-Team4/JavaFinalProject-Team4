import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { SliderModule } from 'angular-image-slider';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgxPopper } from 'angular-popper';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { HeaderComponent } from './component/header/header.component';
import { RegistrationComponent } from './component/registration/registration.component';
import { LoginComponent } from './component/login/login.component';
import { HomepageComponent } from './component/homepage/homepage.component';
import { FooterComponent } from './component/footer/footer.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { JwtInterceptor } from './service/jwt.interceptor';
import { SignUpComponent } from './component/sign-up/sign-up.component';
import { CustomerAccountComponent } from './component/customer-account/customer-account.component';
import { CustomerBalanceComponent } from './component/customer-balance/customer-balance.component';
import { CustomerMiniStatementComponent } from './component/customer-mini-statement/customer-mini-statement.component';
import { BankRepresentativeComponent } from './component/bank-representative/bank-representative.component';
import { CustomerTransferFundsComponent } from './component/customer-transfer-funds/customer-transfer-funds.component';
import { RepresentativeFundDepositComponent } from './component/representative-fund-deposit/representative-fund-deposit.component';
import { RepresentativeServiceComponent } from './component/representative-service/representative-service.component';
import { CustomerPayBillComponent } from './component/customer-pay-bill/customer-pay-bill.component';
import { AddBankAccountComponent } from './component/add-bank-account/add-bank-account.component';
import { AddCardComponent } from './component/add-card/add-card.component';
import { AddPayeeComponent } from './component/add-payee/add-payee.component';
import { RemittanceComponent } from './component/remittance/remittance.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    RegistrationComponent,
    LoginComponent,
    HomepageComponent,
    FooterComponent,
    SignUpComponent,
    CustomerAccountComponent,
    CustomerBalanceComponent,
    CustomerMiniStatementComponent,
    BankRepresentativeComponent,
    CustomerTransferFundsComponent,
    RepresentativeFundDepositComponent,
    RepresentativeServiceComponent,
    CustomerPayBillComponent,
    AddBankAccountComponent,
    AddCardComponent,
    AddPayeeComponent,
    RemittanceComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxPopper,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    FontAwesomeModule,
    HttpClientModule,
    SliderModule
    
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true

  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
