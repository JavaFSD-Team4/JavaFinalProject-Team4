import { PayeeDetails } from './payee-details';

describe('PayeeDetails', () => {
  it('should create an instance', () => {
    expect(new PayeeDetails()).toBeTruthy();
  });
});
