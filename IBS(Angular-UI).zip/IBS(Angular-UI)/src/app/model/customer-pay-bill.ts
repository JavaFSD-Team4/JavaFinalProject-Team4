export class CustomerPayBill {
    public serviceProvider:string;
    public amount:number;
}
