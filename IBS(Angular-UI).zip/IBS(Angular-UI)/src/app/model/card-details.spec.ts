import { CardDetails } from './card-details';

describe('CardDetails', () => {
  it('should create an instance', () => {
    expect(new CardDetails()).toBeTruthy();
  });
});
