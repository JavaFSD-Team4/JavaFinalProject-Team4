export class Signup {

    public adhaarNumber:number;
    public password:string;
    public cPassword:string;

}
