import { CustomerCheckBalance } from './customer-check-balance';

describe('CustomerCheckBalance', () => {
  it('should create an instance', () => {
    expect(new CustomerCheckBalance()).toBeTruthy();
  });
});
