export class CardDetails {
    public cardNum : number;
    public cvv : number;
    public pin : number;
    public expiryDate : Date;
}
