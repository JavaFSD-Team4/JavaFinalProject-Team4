import { CustomerTransferFund } from './customer-transfer-fund';

describe('CustomerTransferFund', () => {
  it('should create an instance', () => {
    expect(new CustomerTransferFund()).toBeTruthy();
  });
});
