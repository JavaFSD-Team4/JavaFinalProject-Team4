export class CustomerTransferFund {
    public recAccountNum:number;
    public accountType:string;
    public remark:string;
    public amount:number;
    public transactionType:string;
    public transactionDate:Date;

}

