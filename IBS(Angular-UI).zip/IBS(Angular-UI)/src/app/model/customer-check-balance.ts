export class CustomerCheckBalance {
    public accNumber:number;
   
}
