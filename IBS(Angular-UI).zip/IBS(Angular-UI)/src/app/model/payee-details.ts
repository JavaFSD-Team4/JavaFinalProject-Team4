export class PayeeDetails {
    public benId : number;
    public benName : string;
    public benAccNum : number;
    public benAccType : number;
}
