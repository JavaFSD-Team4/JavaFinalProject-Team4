export class CustomerDetails {
    
    public custName:string;
    public adharNumber:number;
    public dob:Date;
    public address:string;
    public panNumber:string;
    public bankAccount:string;   
}
