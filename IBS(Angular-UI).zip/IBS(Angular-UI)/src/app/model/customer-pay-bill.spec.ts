import { CustomerPayBill } from './customer-pay-bill';

describe('CustomerPayBill', () => {
  it('should create an instance', () => {
    expect(new CustomerPayBill()).toBeTruthy();
  });
});
