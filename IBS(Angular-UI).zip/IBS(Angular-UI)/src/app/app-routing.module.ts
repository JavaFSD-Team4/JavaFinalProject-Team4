import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomepageComponent } from './component/homepage/homepage.component';
import { LoginComponent } from './component/login/login.component';
import { RegistrationComponent } from './component/registration/registration.component';
import { CustomerAccountComponent } from './component/customer-account/customer-account.component';
import { SignUpComponent } from './component/sign-up/sign-up.component';
import { CustomerBalanceComponent } from './component/customer-balance/customer-balance.component';
import { CustomerTransferFundsComponent } from './component/customer-transfer-funds/customer-transfer-funds.component';
import { CustomerMiniStatementComponent } from './component/customer-mini-statement/customer-mini-statement.component';
import { BankRepresentativeComponent } from './component/bank-representative/bank-representative.component';
import { RepresentativeFundDepositComponent } from './component/representative-fund-deposit/representative-fund-deposit.component';
import { RepresentativeServiceComponent } from './component/representative-service/representative-service.component';
import { CustomerPayBillComponent } from './component/customer-pay-bill/customer-pay-bill.component';
import { RemittanceComponent } from './component/remittance/remittance.component';
import { AddPayeeComponent } from './component/add-payee/add-payee.component';
import { AddCardComponent } from './component/add-card/add-card.component';
import { AddBankAccountComponent } from './component/add-bank-account/add-bank-account.component';


const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: '/home' },
  { path: 'home', component: HomepageComponent },
  { path: 'login', component: LoginComponent},
  { path: 'signup', component: RegistrationComponent },
  {path:'registration',component:SignUpComponent},
  {path:'customer',component:CustomerAccountComponent},
  {path:'customerBalance',component:CustomerBalanceComponent},
  {path:'customerTransferFund',component:CustomerTransferFundsComponent},
  {path:'customerMiniStatement',component:CustomerMiniStatementComponent},
  {path:'bankRepresentative',component:BankRepresentativeComponent},
  {path:'representativeFundTransfer',component:RepresentativeFundDepositComponent},
  {path:'representativeService',component:RepresentativeServiceComponent},
  {path:'customerPayBill',component:CustomerPayBillComponent},
  {path:'remittance',component:RemittanceComponent},
  {path:'addPayee',component:AddPayeeComponent},
  {path:'addCard',component:AddCardComponent},
  {path:'addBankAccount',component:AddBankAccountComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
