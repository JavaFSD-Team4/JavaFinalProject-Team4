import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { CustomerPayBillComponent } from '../component/customer-pay-bill/customer-pay-bill.component';
import { CustomerPayBill } from '../model/customer-pay-bill';

@Injectable({
  providedIn: 'root'
})
export class PayBillService {

  
  bankEndPoint:string;

  constructor(private client:HttpClient) {
    this.bankEndPoint = environment.bankEndPoint;
   }
   getAll():Observable<CustomerPayBill[]>{
     return this.client.get<CustomerPayBill[]>(this.bankEndPoint);
   }

   add(payBill:CustomerPayBill):Observable<CustomerPayBill>{
     return this.client.post<CustomerPayBill>(this.bankEndPoint,CustomerPayBill);
   }

   modify(payBill:CustomerPayBill):Observable<CustomerPayBill>{
     return this.client.put<CustomerPayBill>(this.bankEndPoint,payBill);
   }
}
