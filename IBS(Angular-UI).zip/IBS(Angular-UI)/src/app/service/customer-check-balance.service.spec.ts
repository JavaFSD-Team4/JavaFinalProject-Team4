import { TestBed } from '@angular/core/testing';

import { CustomerCheckBalanceService } from './customer-check-balance.service';

describe('CustomerCheckBalanceService', () => {
  let service: CustomerCheckBalanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomerCheckBalanceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
