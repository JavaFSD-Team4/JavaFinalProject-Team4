import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { PayeeDetails } from '../model/payee-details';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RemittanceService {

  bankEndPoint: string;

  constructor(private client: HttpClient) {
    this.bankEndPoint = environment.bankEndPoint;
  }

  add(payee: PayeeDetails): Observable<PayeeDetails> {
    return this.client.post<PayeeDetails>(this.bankEndPoint, payee);
  }

  modify(payee: PayeeDetails): Observable<PayeeDetails> {
    return this.client.put<PayeeDetails>(this.bankEndPoint, payee);
  }
}
