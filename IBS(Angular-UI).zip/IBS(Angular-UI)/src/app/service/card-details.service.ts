import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { CardDetails } from '../model/card-details';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CardDetailsService {


  bankEndPoint: string;

  constructor(private client: HttpClient) {
    this.bankEndPoint = environment.bankEndPoint;
  }

  add(card: CardDetails): Observable<CardDetails> {
    return this.client.post<CardDetails>(this.bankEndPoint, card);
  }

  modify(card: CardDetails): Observable<CardDetails> {
    return this.client.put<CardDetails>(this.bankEndPoint, card);
  }
}
