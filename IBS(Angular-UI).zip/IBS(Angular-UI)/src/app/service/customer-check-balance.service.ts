import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { CustomerCheckBalance } from '../model/customer-check-balance';

@Injectable({
  providedIn: 'root'
})
export class CustomerCheckBalanceService {

  bankEndPoint:string;

  constructor(private client:HttpClient) { 
    this.bankEndPoint = environment.bankEndPoint;
  }

  getById(accNum:number):Observable<CustomerCheckBalance>{
    return this.client.get<CustomerCheckBalance>(`${this.bankEndPoint}/${accNum}`);
  }
}
