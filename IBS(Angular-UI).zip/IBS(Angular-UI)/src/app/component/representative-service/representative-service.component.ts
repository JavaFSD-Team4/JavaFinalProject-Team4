import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-representative-service',
  templateUrl: './representative-service.component.html',
  styleUrls: ['./representative-service.component.css']
})
export class RepresentativeServiceComponent implements OnInit {
  serviceForm:FormGroup;
  serviceName:string[];
  errIcon=faExclamationTriangle;
  constructor(
      private activatedRoute: ActivatedRoute,
     // private userService: SignUpService,
      private router: Router,
      private formBuilder: FormBuilder) {
      this.serviceForm = formBuilder.group({
  
        serviceId: ['',Validators.required],
        serviceName:['',Validators.required],
        fixedAmount:['',Validators.required]
    
  }); 

    this.serviceName = ["Mobile Postpaid", "Electricity", "Cridit Card", "Rental Payment", "Loan", "Tax"];
   }

  ngOnInit(): void {
  }

  
  get f(){
    return this.serviceForm.controls;

  }
  save(){

  }
}
