import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RepresentativeServiceComponent } from './representative-service.component';

describe('RepresentativeServiceComponent', () => {
  let component: RepresentativeServiceComponent;
  let fixture: ComponentFixture<RepresentativeServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RepresentativeServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RepresentativeServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
