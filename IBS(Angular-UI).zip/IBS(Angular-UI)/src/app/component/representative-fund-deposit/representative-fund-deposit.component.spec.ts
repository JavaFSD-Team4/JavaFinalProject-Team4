import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RepresentativeFundDepositComponent } from './representative-fund-deposit.component';

describe('RepresentativeFundDepositComponent', () => {
  let component: RepresentativeFundDepositComponent;
  let fixture: ComponentFixture<RepresentativeFundDepositComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RepresentativeFundDepositComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RepresentativeFundDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
