import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-representative-fund-deposit',
  templateUrl: './representative-fund-deposit.component.html',
  styleUrls: ['./representative-fund-deposit.component.css']
})
export class RepresentativeFundDepositComponent implements OnInit {

  transferForm: FormGroup;
  errIcon = faExclamationTriangle;
  constructor(private activatedRoute: ActivatedRoute,
    private router: Router,
    private formBuilder: FormBuilder) {
    this.transferForm = formBuilder.group({
      accNum: ['',Validators.required],
      ifsc:['',Validators.required],
      recipientName:['',Validators.required],
      amount:['',Validators.required]
    });
  }

  get f() {
    return this.transferForm.controls;
  }
  ngOnInit(): void {
  }

  transfer() {

  }
}
