import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remittance',
  templateUrl: './remittance.component.html',
  styleUrls: ['./remittance.component.css']
})
export class RemittanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
