import { Component, OnInit } from '@angular/core';
import { FaSymbol } from '@fortawesome/fontawesome-svg-core';

@Component({
  selector: 'app-customer-account',
  templateUrl: './customer-account.component.html',
  styleUrls: ['./customer-account.component.css']
})
export class CustomerAccountComponent implements OnInit {

  faBalance:FaSymbol;
  constructor() { }

  ngOnInit(): void {
  }

}
