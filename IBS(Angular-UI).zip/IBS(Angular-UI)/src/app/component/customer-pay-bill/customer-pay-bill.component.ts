import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';
import { ActivatedRoute, Router } from '@angular/router';
import { PayBillService } from 'src/app/service/pay-bill.service';

@Component({
  selector: 'app-customer-pay-bill',
  templateUrl: './customer-pay-bill.component.html',
  styleUrls: ['./customer-pay-bill.component.css']
})
export class CustomerPayBillComponent implements OnInit {

  
  payForm: FormGroup;
  serviceProviders:string[];
  errIcon = faExclamationTriangle;
  constructor(
    private activatedRoute: ActivatedRoute,
    private payService: PayBillService,
    private router: Router,
    private formBuilder: FormBuilder
  ) {
    this.payForm = formBuilder.group({
      serviceProvider: ['',Validators.required],
      amount: ['',Validators.required]
   });

   this.serviceProviders = ["Mobile Postpaid", "Electricity", "Cridit Card", "Rental Payment", "Loan", "Tax"];
  }
   get f(){
    return this.payForm.controls;
  }
  ngOnInit(): void {
  }

  save(){
    let obr = this.payService.add(this.payForm.value);
    obr.subscribe(
      (data) => {this.router.navigateByUrl("/paybills");},
      (err)=>{console.log(err.message);}
    );
  }
}

