import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerPayBillComponent } from './customer-pay-bill.component';

describe('CustomerPayBillComponent', () => {
  let component: CustomerPayBillComponent;
  let fixture: ComponentFixture<CustomerPayBillComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerPayBillComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerPayBillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
