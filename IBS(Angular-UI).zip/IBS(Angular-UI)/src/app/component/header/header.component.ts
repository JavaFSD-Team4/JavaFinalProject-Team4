import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import { faHome, faCartPlus, faList, faSign, faLock, faSignOutAlt, faSignInAlt } from '@fortawesome/free-solid-svg-icons';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/service/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  logo:any;
  brandName:string;
  links:any[];

  
  isLoggedIn: boolean;
  custId: string;


  constructor(private router:Router,private authService:AuthService) {
    this.logo = environment.logo;
    this.brandName= environment.appTitle;
    this.links = [
      {icon:faHome,path:'/home',linkText:'Home'},
      {icon:faSignInAlt,path:'/signup',linkText:'Sign Up'},
      {icon:faSignOutAlt,path:'/login',linkText:'LogIn'}
    
    ]
   }

  ngOnInit(): void {
    this.authService.loginStatus.subscribe(
      (status) => {
        this.isLoggedIn = status;
        if(this.isLoggedIn){
          this.custId = sessionStorage.getItem('custId');
        }
      }
    );
  }

  logout(){
   // this.authService.logout();
   this.router.navigateByUrl("/home");
  }

}
