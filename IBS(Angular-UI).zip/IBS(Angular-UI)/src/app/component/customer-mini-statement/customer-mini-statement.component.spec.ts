import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerMiniStatementComponent } from './customer-mini-statement.component';

describe('CustomerMiniStatementComponent', () => {
  let component: CustomerMiniStatementComponent;
  let fixture: ComponentFixture<CustomerMiniStatementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerMiniStatementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerMiniStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
