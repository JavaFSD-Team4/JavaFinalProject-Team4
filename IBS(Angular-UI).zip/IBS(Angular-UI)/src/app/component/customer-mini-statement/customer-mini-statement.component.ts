import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-mini-statement',
  templateUrl: './customer-mini-statement.component.html',
  styleUrls: ['./customer-mini-statement.component.css']
})
export class CustomerMiniStatementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
