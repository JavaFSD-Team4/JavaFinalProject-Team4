import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-representative',
  templateUrl: './bank-representative.component.html',
  styleUrls: ['./bank-representative.component.css']
})
export class BankRepresentativeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
