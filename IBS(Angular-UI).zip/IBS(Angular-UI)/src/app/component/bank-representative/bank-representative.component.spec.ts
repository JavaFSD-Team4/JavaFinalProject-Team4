import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankRepresentativeComponent } from './bank-representative.component';

describe('BankRepresentativeComponent', () => {
  let component: BankRepresentativeComponent;
  let fixture: ComponentFixture<BankRepresentativeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankRepresentativeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankRepresentativeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
