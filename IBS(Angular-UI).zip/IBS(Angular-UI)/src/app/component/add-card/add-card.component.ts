import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';
import { ActivatedRoute, Router } from '@angular/router';
import { CardDetailsService } from 'src/app/service/card-details.service';

@Component({
  selector: 'app-add-card',
  templateUrl: './add-card.component.html',
  styleUrls: ['./add-card.component.css']
})
export class AddCardComponent implements OnInit {

  cardForm:FormGroup;
  errIcon=faExclamationTriangle;
  constructor(
    private activatedRoute: ActivatedRoute,
    private cardService: CardDetailsService,
    private router: Router,
    private formBuilder: FormBuilder
  ) { 
    this.cardForm = formBuilder.group({
      cardNum: ['', Validators.required],
      cvv: ['', Validators.required],
      pin: ['', Validators.required],
      expiryDate: ['', Validators.required]
    });
  }

  get f() {
    return this.cardForm.controls;

  }

  ngOnInit(): void {
  }

  
  save() {
    let obr = this.cardService.add(this.cardForm.value);

    obr.subscribe(
      (data) => { this.router.navigateByUrl("/"); },
      (err) => { console.log(err.message); }
    );

  }

}
