import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { faExclamationTriangle, faSave } from '@fortawesome/free-solid-svg-icons';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-customer-transfer-funds',
  templateUrl: './customer-transfer-funds.component.html',
  styleUrls: ['./customer-transfer-funds.component.css']
})
export class CustomerTransferFundsComponent implements OnInit {

  transferFundForm:FormGroup;
  accountTypes:string[];

  errIcon=faExclamationTriangle;
  btnIcon= faSave;
  constructor(
    private fb:FormBuilder,
    private activatedRoute: ActivatedRoute,
    private router:Router
  ) {
    this.transferFundForm = fb.group({
      
      recAccountNum:['',Validators.required],
      accountType:['',Validators.required],
      amount:['',[Validators.required,Validators.minLength(100),Validators.maxLength(2500)]],
      bankAccount: ['',Validators.required],
      remark: ['',Validators.required],
      transactionType: ['',Validators.required],
      transactionDate: ['',Validators.required]
      
   });

   this.accountTypes = ["Saving Account","Current Account","Salary account"];
  }
  get f(){
    return this.transferFundForm.controls;
  }
  ngOnInit(): void {
  }

  save(){
    
  }
}
