import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';
import { ActivatedRoute, Router } from '@angular/router';
import { RemittanceService } from 'src/app/service/remittance.service';

@Component({
  selector: 'app-add-payee',
  templateUrl: './add-payee.component.html',
  styleUrls: ['./add-payee.component.css']
})
export class AddPayeeComponent implements OnInit {

  payeeForm: FormGroup;
  benAccType: string[];
  errIcon = faExclamationTriangle;
  constructor(
    private activatedRoute: ActivatedRoute,
    private remittanceService: RemittanceService,
    private router: Router,
    private formBuilder: FormBuilder
  ) { 
    this.payeeForm = formBuilder.group({
      benId: ['', Validators.required],
      benName: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(45)]],
      benAccNum: ['', Validators.required],
      benAccType: ['', Validators.required]
    });
    this.benAccType = ["Saving Account", "Current Account", "Salary account"];

  }

  get f() {
    return this.payeeForm.controls;

  }
  ngOnInit(): void {
  }

  save() {
    let obr = this.remittanceService.add(this.payeeForm.value);

    obr.subscribe(
      (data) => { this.router.navigateByUrl("/"); },
      (err) => { console.log(err.message); }
    );

  }

}
