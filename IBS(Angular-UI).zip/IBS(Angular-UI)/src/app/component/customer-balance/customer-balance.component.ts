import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerCheckBalanceService } from 'src/app/service/customer-check-balance.service';
import { faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-customer-balance',
  templateUrl: './customer-balance.component.html',
  styleUrls: ['./customer-balance.component.css']
})
export class CustomerBalanceComponent implements OnInit {

  checkBal: FormGroup;
  errIcon=faExclamationTriangle;
  constructor(
    private activatedRoute: ActivatedRoute,
    private router:Router,
    private customerBalance:CustomerCheckBalanceService,
    private formBuilder:FormBuilder
  )
   { 
     this.checkBal = formBuilder.group({
       accNumber:['',Validators.required]
     });
  }

  get f(){
    return this.checkBal.controls;
  }
  ngOnInit(): void {
  }
  save(){
    let obr = this.customerBalance.getById(this.checkBal.value);

    obr.subscribe(
      (data) => {
        this.router.navigateByUrl("#");
      },
      (err) => {console.log(err.message);}
    );
  }

}
