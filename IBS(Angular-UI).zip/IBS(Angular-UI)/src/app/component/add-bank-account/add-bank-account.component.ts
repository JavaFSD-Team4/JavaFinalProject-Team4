import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-bank-account',
  templateUrl: './add-bank-account.component.html',
  styleUrls: ['./add-bank-account.component.css']
})
export class AddBankAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
