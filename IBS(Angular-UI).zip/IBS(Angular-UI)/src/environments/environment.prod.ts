export const environment = {
  production: true,
  appTitle: "Integrated Banking System",
  logo:"/dist/assets/images/ibs.jpg",
  bankEndPoint:"",
  loginEndPoint:"",
  regEndPoint:""
};
