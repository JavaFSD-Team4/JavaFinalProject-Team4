import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { Signup } from '../model/signup';

@Injectable({
  providedIn: 'root'
})
export class SignUpService {

  bankEndPoint:string;
  constructor(private client: HttpClient) { 
    this.bankEndPoint = environment.bankEndPoint;
  }

  getAll() : Observable<Signup[]>{
    return this.client.get<Signup[]>(this.bankEndPoint);
  }

  getById(custId:number):Observable<Signup>{
    return this.client.get<Signup>(`${this.bankEndPoint}/${custId}`);
  }

  add(signup:Signup):Observable<Signup>{
    return this.client.post<Signup>(this.bankEndPoint,signup);
  }
  modify(signup:Signup):Observable<Signup>{
    return this.client.put<Signup>(this.bankEndPoint,signup);
  }
}
